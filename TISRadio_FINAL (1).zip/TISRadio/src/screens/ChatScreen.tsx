import React from "react";
import {View, ActivityIndicator} from "react-native";
import {SafeAreaView} from "react-native-safe-area-context";
import {WebView} from "react-native-webview";

export default function ChatScreen() {
  return (
    <SafeAreaView style={{flex:1, backgroundColor:"#07070f"}}>
      <WebView
        source={{uri: "https://tisradiochat.chatbro.com"}}
        style={{flex:1, backgroundColor:"#07070f"}}
        startInLoadingState
        renderLoading={() => (
          <View style={{flex:1, alignItems:"center", justifyContent:"center", backgroundColor:"#07070f"}}>
            <ActivityIndicator size="large" color="#a855f7" />
          </View>
        )}
        javaScriptEnabled
        domStorageEnabled
        allowsInlineMediaPlayback
      />
    </SafeAreaView>
  );
}
