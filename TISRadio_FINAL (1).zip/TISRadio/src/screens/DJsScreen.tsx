import React from "react";
import {View, Text, FlatList, TouchableOpacity, Linking, Image} from "react-native";
import {SafeAreaView} from "react-native-safe-area-context";

const DJS = [
  {id:"maxday", name:"MaxDay", schedule:"ПТ & СБ — 20:00", genre:"Trance", url:"https://tranceisstar.top/dj-maxday.html", photo:"https://i.postimg.cc/q78m81Dm/photo_2026_02_16_15_03_55.jpg"},
  {id:"raiskiy", name:"RAISKIY", schedule:"НД — 13:00", genre:"Liquid D&B", url:"https://tranceisstar.top/dj-raiskiy.html", photo:"https://i.postimg.cc/PqmGkYhD/RAISKIY1.jpg"},
  {id:"cjmover", name:"Cj Mover", schedule:"ПТ & СБ — 13:00", genre:"Trance", url:"https://tranceisstar.top/dj-cjmover.html", photo:"https://i.postimg.cc/kXJX98Rw/mover.jpg"},
  {id:"boriskross", name:"Boris Kross", schedule:"ПТ & СБ — 16:00", genre:"Trance", url:"https://tranceisstar.top/dj-boriskross.html", photo:"https://i.postimg.cc/ZnLgVWT5/photo-2025-01-29-15-48-57.png"},
  {id:"gazestor", name:"Gazestor", schedule:"ПТ & СБ — 11:00", genre:"Trance", url:"https://tranceisstar.top/dj-gazestor.html", photo:"https://i.postimg.cc/d3QnQ4YJ/gazestor.jpg"},
  {id:"dj4wd", name:"DJ4wd", schedule:"ПТ & СБ — 17:00", genre:"Trance", url:"https://tranceisstar.top/dj-dj4wd.html", photo:"https://i.postimg.cc/R09tzq9B/dj4wd.png"},
  {id:"okua", name:"OK[UA]", schedule:"ПТ & СБ — 19:00", genre:"Trance", url:"https://tranceisstar.top/dj-okua.html", photo:"https://i.postimg.cc/8zZ2mv6h/Chat-GPT-Image-27-apr-2026-g-10-45-52.png"},
  {id:"svnagel", name:"SVnagel", schedule:"ПТ & СБ — 21:00", genre:"Trance", url:"https://tranceisstar.top/dj-svnagel.html", photo:"https://i.postimg.cc/prLXP9jQ/svnagel1.jpg"},
  {id:"rayandrey", name:"Ray AndRey", schedule:"ПТ & СБ — 15:00", genre:"Trance", url:"https://tranceisstar.top/dj-rayandrey.html", photo:"https://i.postimg.cc/SRZ1njTB/photo_2020_11_4413_17_05_34.png"},
  {id:"hidingdeep", name:"Hiding Deep", schedule:"ПТ & СБ — 18:00", genre:"Trance", url:"https://tranceisstar.top/dj-hidingdeep.html", photo:"https://i.postimg.cc/fR7cFbYD/hiding_deep.jpg"},
  {id:"necsts", name:"NecSts", schedule:"ПТ & СБ — 10:00", genre:"Trance", url:"https://tranceisstar.top/dj-necsts.html", photo:"https://i.postimg.cc/RCWpXS24/necsts.png"},
  {id:"vysotskiy", name:"Vysotskiy", schedule:"НД — 14:00", genre:"Trance", url:"https://tranceisstar.top/dj-vysotskiy.html", photo:"https://i.postimg.cc/3x1h703W/photo-2026-04-25-09-57-14.jpg"},
  {id:"djkrissb", name:"DJ KRISS B", schedule:"ПТ & СБ — 22:00", genre:"Trance", url:"https://tranceisstar.top/dj-djkrissb.html", photo:"https://i.postimg.cc/1trjZvD7/160137552_3928500043876562_8508103954376704862_n.jpg"},
];

export default function DJsScreen() {
  return (
    <SafeAreaView style={{flex:1, backgroundColor:"#07070f"}}>
      <View style={{padding:20, paddingBottom:4}}>
        <Text style={{color:"#fff", fontSize:24, fontWeight:"900"}}>Резидент-діджеї</Text>
        <Text style={{color:"#4a3a6a", fontSize:12, marginTop:2}}>{DJS.length} артистів TIS Radio</Text>
      </View>
      <FlatList
        data={DJS}
        keyExtractor={d => d.id}
        contentContainerStyle={{paddingHorizontal:20, paddingBottom:40}}
        renderItem={({item}) => (
          <TouchableOpacity onPress={() => Linking.openURL(item.url)}
            style={{flexDirection:"row", alignItems:"center", backgroundColor:"rgba(255,255,255,0.04)", borderRadius:16, marginBottom:10, borderWidth:1, borderColor:"rgba(168,85,247,0.18)", overflow:"hidden"}}>
            <Image source={{uri: item.photo}} style={{width:68, height:68}} resizeMode="cover"
              defaultSource={require("../../assets/images/icon.png")} />
            <View style={{flex:1, padding:12}}>
              <Text style={{color:"#fff", fontSize:16, fontWeight:"800"}}>{item.name}</Text>
              <Text style={{color:"#9333ea", fontSize:12, marginTop:2}}>{item.schedule}</Text>
              <View style={{alignSelf:"flex-start", backgroundColor:"rgba(147,51,234,0.2)", borderRadius:6, paddingVertical:2, paddingHorizontal:7, marginTop:4, borderWidth:1, borderColor:"rgba(147,51,234,0.4)"}}>
                <Text style={{color:"#c084fc", fontSize:9, fontWeight:"700"}}>{item.genre}</Text>
              </View>
            </View>
            <Text style={{color:"#4a3a6a", fontSize:22, paddingRight:14}}>›</Text>
          </TouchableOpacity>
        )}
      />
    </SafeAreaView>
  );
}
