import React from "react";
import {View, Text, ScrollView, TouchableOpacity, Linking} from "react-native";
import {SafeAreaView} from "react-native-safe-area-context";

export default function AboutScreen() {
  return (
    <SafeAreaView style={{flex:1, backgroundColor:"#07070f"}}>
      <ScrollView contentContainerStyle={{padding:20, paddingBottom:50}}>
        <View style={{alignItems:"center", paddingTop:16, marginBottom:24}}>
          <View style={{backgroundColor:"rgba(168,85,247,0.15)", borderRadius:20, paddingVertical:5, paddingHorizontal:16, borderWidth:1, borderColor:"rgba(168,85,247,0.4)", marginBottom:12}}>
            <Text style={{color:"#c084fc", fontSize:10, fontWeight:"800", letterSpacing:2}}>З 2010 · 15 YEARS</Text>
          </View>
          <Text style={{color:"#fff", fontSize:26, fontWeight:"900", letterSpacing:4, textShadowColor:"#a855f7", textShadowRadius:20, textAlign:"center"}}>TRANCE IS STAR</Text>
          <Text style={{color:"#9333ea", fontSize:13, letterSpacing:1, marginTop:4, marginBottom:14}}>Underground Frequency · Ukraine</Text>
          <Text style={{color:"#6b5a9a", fontSize:14, textAlign:"center", lineHeight:22}}>Андерграундна електронна радіостанція з України, яка транслює якісну електронну музику 24/7 з 2010 року.</Text>
        </View>

        <View style={{flexDirection:"row", gap:10, marginBottom:24, flexWrap:"wrap"}}>
          {[["15","Років в ефірі"],["13","Резидентів"],["320","kbps"],["24/7","Мовлення"]].map(([v,l]) => (
            <View key={l} style={{flex:1, minWidth:"20%", backgroundColor:"rgba(168,85,247,0.08)", borderRadius:14, padding:14, alignItems:"center", borderWidth:1, borderColor:"rgba(168,85,247,0.2)"}}>
              <Text style={{color:"#e9d5ff", fontSize:22, fontWeight:"900"}}>{v}</Text>
              <Text style={{color:"#6b5a9a", fontSize:9, fontWeight:"600", marginTop:2, textAlign:"center"}}>{l}</Text>
            </View>
          ))}
        </View>

        <Text style={{color:"#fff", fontSize:16, fontWeight:"800", marginBottom:12}}>Соціальні мережі</Text>
        {[
          {label:"✈ Telegram", url:"https://t.me/tranceisstar", color:"#229ed9"},
          {label:"☁ Mixcloud", url:"https://www.mixcloud.com/tranceisstar/", color:"#5000ff"},
          {label:"◎ SoundCloud", url:"https://soundcloud.com/tranceisstar", color:"#ff5500"},
          {label:"🌐 Вебсайт", url:"https://tranceisstar.top/", color:"#a855f7"},
        ].map(link => (
          <TouchableOpacity key={link.url} onPress={() => Linking.openURL(link.url)}
            style={{backgroundColor:"rgba(255,255,255,0.04)", borderRadius:12, padding:14, flexDirection:"row", justifyContent:"space-between", marginBottom:8, borderWidth:1, borderColor:"rgba(255,255,255,0.06)", borderLeftWidth:3, borderLeftColor:link.color}}>
            <Text style={{color:"#e9d5ff", fontSize:14}}>{link.label}</Text>
            <Text style={{color:"#4a3a6a", fontSize:18}}>→</Text>
          </TouchableOpacity>
        ))}

        <View style={{backgroundColor:"rgba(255,255,255,0.04)", borderRadius:18, padding:20, marginTop:16, borderWidth:1, borderColor:"rgba(255,255,255,0.06)"}}>
          <Text style={{color:"#fff", fontSize:17, fontWeight:"800", marginBottom:8}}>💳 Підтримати радіо</Text>
          <Text style={{color:"#6b5a9a", fontSize:13, lineHeight:20, marginBottom:12}}>TIS Radio існує завдяки вашій підтримці.</Text>
          <Text style={{color:"#a855f7", fontSize:18, fontWeight:"800", letterSpacing:2, textAlign:"center", marginBottom:14}}>5375 4112 0246 0460</Text>
          <TouchableOpacity style={{backgroundColor:"#6b21a8", borderRadius:14, padding:14, alignItems:"center"}} onPress={() => Linking.openURL("https://send.monobank.ua/jar/52Tw9fEaxg")}>
            <Text style={{color:"#fff", fontSize:15, fontWeight:"700"}}>💛 Підтримати через Monobank</Text>
          </TouchableOpacity>
        </View>

        <Text style={{color:"#2d2040", fontSize:11, textAlign:"center", marginTop:20, letterSpacing:1}}>© 2010–2026 TRANCE IS STAR RADIO · UKRAINE</Text>
      </ScrollView>
    </SafeAreaView>
  );
}
