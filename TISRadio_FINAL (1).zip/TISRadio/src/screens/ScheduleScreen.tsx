import React, {useState} from "react";
import {View, Text, ScrollView, TouchableOpacity} from "react-native";
import {SafeAreaView} from "react-native-safe-area-context";

const SCHEDULE = {
  "ПН": [{time:"00:00",dj:"Автоплейлист"},{time:"12:00",dj:"Автоплейлист"}],
  "ВТ": [{time:"00:00",dj:"Автоплейлист"},{time:"12:00",dj:"Автоплейлист"}],
  "СР": [{time:"00:00",dj:"Автоплейлист"},{time:"12:00",dj:"Автоплейлист"}],
  "ЧТ": [{time:"00:00",dj:"Автоплейлист"},{time:"12:00",dj:"Автоплейлист"}],
  "ПТ": [
    {time:"10:00",dj:"NecSts"},{time:"11:00",dj:"Gazestor"},
    {time:"13:00",dj:"Cj Mover"},{time:"15:00",dj:"Ray AndRey"},
    {time:"16:00",dj:"Boris Kross"},{time:"17:00",dj:"DJ4wd"},
    {time:"18:00",dj:"Hiding Deep"},{time:"19:00",dj:"OK[UA]"},
    {time:"20:00",dj:"MaxDay"},{time:"21:00",dj:"SVnagel"},
    {time:"22:00",dj:"DJ KRISS B"},
  ],
  "СБ": [
    {time:"10:00",dj:"NecSts"},{time:"11:00",dj:"Gazestor"},
    {time:"13:00",dj:"Cj Mover"},{time:"15:00",dj:"Ray AndRey"},
    {time:"16:00",dj:"Boris Kross"},{time:"17:00",dj:"DJ4wd"},
    {time:"18:00",dj:"Hiding Deep"},{time:"19:00",dj:"OK[UA]"},
    {time:"20:00",dj:"MaxDay"},{time:"21:00",dj:"SVnagel"},
    {time:"22:00",dj:"DJ KRISS B"},
  ],
  "НД": [
    {time:"13:00",dj:"RAISKIY"},{time:"14:00",dj:"Vysotskiy"},
  ],
};

const DAYS = ["ПН","ВТ","СР","ЧТ","ПТ","СБ","НД"];

function todayDay() {
  const d = new Date().getDay();
  return ["НД","ПН","ВТ","СР","ЧТ","ПТ","СБ"][d];
}

export default function ScheduleScreen() {
  const [day, setDay] = useState(todayDay());
  const slots = SCHEDULE[day] || [];
  const nowH = new Date().getHours();

  const isNow = (time: string) => {
    if (day !== todayDay()) return false;
    const h = parseInt(time.split(":")[0]);
    return nowH >= h && nowH < h + 2;
  };

  return (
    <SafeAreaView style={{flex:1, backgroundColor:"#07070f"}}>
      <View style={{padding:20, paddingBottom:0}}>
        <Text style={{color:"#fff", fontSize:24, fontWeight:"900", letterSpacing:1}}>Розклад ефірів</Text>
        <Text style={{color:"#4a3a6a", fontSize:12, marginTop:2, marginBottom:14}}>Резидентські шоу щотижня</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginBottom:16}}>
          <View style={{flexDirection:"row", gap:8}}>
            {DAYS.map(d => (
              <TouchableOpacity key={d} onPress={() => setDay(d)}
                style={{backgroundColor:d===day?"rgba(147,51,234,0.2)":"rgba(255,255,255,0.04)", borderRadius:12, paddingVertical:10, paddingHorizontal:16, borderWidth:1, borderColor:d===day?"#9333ea":"rgba(255,255,255,0.06)"}}>
                <Text style={{color:d===day?"#a855f7":"#4a3a6a", fontSize:14, fontWeight:"900"}}>{d}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      </View>
      <ScrollView contentContainerStyle={{paddingHorizontal:20, paddingBottom:40}}>
        {slots.map((slot, i) => {
          const active = isNow(slot.time);
          return (
            <View key={i} style={{flexDirection:"row", alignItems:"flex-start", marginBottom:8}}>
              <Text style={{color:active?"#a855f7":"#4a3a6a", fontSize:12, fontWeight:"600", width:52, paddingTop:10, textAlign:"right", marginRight:8}}>{slot.time}</Text>
              <View style={{width:8, height:8, borderRadius:4, backgroundColor:active?"#a855f7":"#1a1030", marginTop:12, marginRight:10, flexShrink:0}} />
              <View style={{flex:1, backgroundColor:active?"rgba(147,51,234,0.12)":"rgba(255,255,255,0.03)", borderRadius:12, padding:10, borderWidth:1, borderColor:active?"rgba(147,51,234,0.4)":"rgba(255,255,255,0.05)"}}>
                {active && (
                  <View style={{flexDirection:"row", alignItems:"center", marginBottom:3}}>
                    <View style={{width:5, height:5, borderRadius:3, backgroundColor:"#22c55e", marginRight:5}} />
                    <Text style={{color:"#22c55e", fontSize:9, fontWeight:"800", letterSpacing:2}}>ЗАРАЗ В ЕФІРІ</Text>
                  </View>
                )}
                <Text style={{color:active?"#fff":"#e9d5ff", fontSize:15, fontWeight:"700"}}>{slot.dj}</Text>
              </View>
            </View>
          );
        })}
      </ScrollView>
    </SafeAreaView>
  );
}
