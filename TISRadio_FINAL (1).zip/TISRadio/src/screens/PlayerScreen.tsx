import React, {useState, useEffect, useRef} from "react";
import {View, Text, TouchableOpacity, ScrollView, Animated, Linking, ActivityIndicator, Image} from "react-native";
import {SafeAreaView} from "react-native-safe-area-context";
import {useAudioPlayer, useAudioPlayerStatus, AudioSource} from "expo-audio";

const STREAM_URL = "https://listen1.myradio24.com/tisradio";
const STATUS_API = "http://myradio24.com/users/tisradio/status.json";
const IMG_BASE = "https://myradio24.com/";

export default function PlayerScreen() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [song, setSong] = useState("Натисніть play щоб слухати");
  const [artist, setArtist] = useState("");
  const [cover, setCover] = useState(null);
  const [listeners, setListeners] = useState(0);
  const [history, setHistory] = useState([]);
  const [favorites, setFavorites] = useState([]);
  const pulse = useRef(new Animated.Value(1)).current;
  const pulseRef = useRef(null);

  const player = useAudioPlayer(null);

  useEffect(() => {
    fetchStatus();
    const t = setInterval(fetchStatus, 15000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (isPlaying) {
      pulseRef.current = Animated.loop(Animated.sequence([
        Animated.timing(pulse, {toValue: 1.08, duration: 1200, useNativeDriver: true}),
        Animated.timing(pulse, {toValue: 1, duration: 1200, useNativeDriver: true}),
      ]));
      pulseRef.current.start();
    } else {
      if (pulseRef.current) pulseRef.current.stop();
      pulse.setValue(1);
    }
  }, [isPlaying]);

  const fetchStatus = async () => {
    try {
      const r = await fetch(STATUS_API);
      const d = await r.json();
      if (d.song) setSong(d.song);
      if (d.artist) setArtist(d.artist);
      if (d.listeners) setListeners(Number(d.listeners));
      if (d.imgbig) setCover(IMG_BASE + d.imgbig);
      else if (d.img) setCover(IMG_BASE + d.img);
      if (d.songs) setHistory(d.songs.slice(0, 5));
    } catch(e) {}
  };

  const handlePlay = async () => {
    try {
      setIsLoading(true);
      player.replace({uri: STREAM_URL});
      player.play();
      setIsPlaying(true);
      setTimeout(() => setIsLoading(false), 3000);
    } catch(e) {
      setIsLoading(false);
      setIsPlaying(false);
    }
  };

  const handleStop = () => {
    try {
      player.pause();
    } catch(e) {}
    setIsPlaying(false);
    setIsLoading(false);
  };

  const toggleFav = () => {
    setFavorites(prev =>
      prev.includes(song) ? prev.filter(f => f !== song) : [song, ...prev].slice(0, 20)
    );
  };

  const isFav = favorites.includes(song);
  const ORB = 160;

  return (
    <SafeAreaView style={{flex:1, backgroundColor:"#07070f"}}>
      <ScrollView contentContainerStyle={{alignItems:"center", paddingHorizontal:20, paddingBottom:50}} showsVerticalScrollIndicator={false}>

        <View style={{alignItems:"center", paddingTop:16, marginBottom:20}}>
          <Text style={{color:"#3d2f60", fontSize:10, letterSpacing:3, marginBottom:4}}>З 2010 РОКУ · UKRAINE</Text>
          <Text style={{color:"#fff", fontSize:26, fontWeight:"900", letterSpacing:4, textShadowColor:"#a855f7", textShadowRadius:24}}>TRANCE IS STAR</Text>
          <Text style={{color:"#9333ea", fontSize:12, letterSpacing:1, marginTop:3}}>Underground Electronic Radio</Text>
        </View>

        <View style={{alignItems:"center", marginBottom:16, width:ORB+60, height:ORB+60, justifyContent:"center"}}>
          <Animated.View style={{position:"absolute", width:ORB+56, height:ORB+56, borderRadius:999, borderWidth:1, borderColor:"rgba(168,85,247,0.1)", transform:[{scale:pulse}]}} />
          <Animated.View style={{position:"absolute", width:ORB+30, height:ORB+30, borderRadius:999, borderWidth:1, borderColor:"rgba(168,85,247,0.2)", transform:[{scale:pulse}]}} />
          <View style={{width:ORB, height:ORB, borderRadius:ORB/2, backgroundColor:"#0d0020", borderWidth:2, borderColor:"#6b21a8", overflow:"hidden", alignItems:"center", justifyContent:"center", elevation:20}}>
            {cover ? (
              <Image source={{uri: cover}} style={{width:ORB, height:ORB}} resizeMode="cover" />
            ) : (
              <>
                <Text style={{color:"#e9d5ff", fontSize:22, fontWeight:"900", letterSpacing:4}}>TIS</Text>
                <Text style={{color:"#7c3aed", fontSize:11, fontWeight:"700", letterSpacing:6}}>RADIO</Text>
              </>
            )}
          </View>
          {isPlaying && (
            <View style={{position:"absolute", bottom:0, flexDirection:"row", alignItems:"center", backgroundColor:"rgba(34,197,94,0.12)", borderRadius:20, paddingVertical:4, paddingHorizontal:12, borderWidth:1, borderColor:"rgba(34,197,94,0.3)"}}>
              <View style={{width:6, height:6, borderRadius:99, backgroundColor:"#22c55e", marginRight:6}} />
              <Text style={{color:"#22c55e", fontSize:10, fontWeight:"800", letterSpacing:2}}>LIVE · 320 kbps</Text>
            </View>
          )}
        </View>

        <View style={{width:"100%", backgroundColor:"rgba(255,255,255,0.04)", borderRadius:18, padding:16, marginBottom:16, borderWidth:1, borderColor:"rgba(168,85,247,0.18)"}}>
          <Text style={{color:"#3d2f60", fontSize:9, letterSpacing:2, marginBottom:6}}>🎵 ЗАРАЗ ГРАЄ</Text>
          {artist ? <Text style={{color:"#a855f7", fontSize:13, fontWeight:"700", marginBottom:2}}>{artist}</Text> : null}
          <Text style={{color:"#fff", fontSize:15, fontWeight:"700", lineHeight:22, marginBottom:10}} numberOfLines={2}>{song}</Text>
          <View style={{flexDirection:"row", alignItems:"center", justifyContent:"space-between"}}>
            {listeners > 0 && <Text style={{color:"#7c3aed", fontSize:11, fontWeight:"600"}}>👥 {listeners} онлайн</Text>}
            <TouchableOpacity onPress={toggleFav} style={{flexDirection:"row", alignItems:"center", backgroundColor:"rgba(168,85,247,0.12)", borderRadius:20, paddingVertical:4, paddingHorizontal:10, borderWidth:1, borderColor:"rgba(168,85,247,0.3)"}}>
              <Text style={{color:"#f0abfc", fontSize:13, marginRight:4}}>{isFav ? "★" : "☆"}</Text>
              <Text style={{color:"#c084fc", fontSize:10, fontWeight:"600"}}>{isFav ? "В обраних" : "В обране"}</Text>
            </TouchableOpacity>
          </View>
        </View>

        <TouchableOpacity
          style={{width:86, height:86, borderRadius:43, backgroundColor:isPlaying?"#2d004d":"#1a0035", borderWidth:2, borderColor:isPlaying?"#a855f7":"#6b21a8", alignItems:"center", justifyContent:"center", marginBottom:8, elevation:16}}
          onPress={() => isPlaying ? handleStop() : handlePlay()}
          activeOpacity={0.8}>
          {isLoading ? <ActivityIndicator size="large" color="#fff" /> : <Text style={{fontSize:34}}>{isPlaying ? "⏸" : "▶"}</Text>}
        </TouchableOpacity>
        <Text style={{color:"#3d2f60", fontSize:12, marginBottom:20}}>{isLoading ? "Буферизація..." : isPlaying ? "Зупинити" : "Слухати"}</Text>

        <View style={{flexDirection:"row", gap:8, marginBottom:20, width:"100%"}}>
          {[
            {icon:"✈", label:"Telegram", url:"https://t.me/tranceisstar"},
            {icon:"☁", label:"Mixcloud", url:"https://www.mixcloud.com/tranceisstar/"},
            {icon:"◎", label:"SoundCloud", url:"https://soundcloud.com/tranceisstar"},
            {icon:"💳", label:"Підтримати", url:"https://send.monobank.ua/jar/52Tw9fEaxg"},
          ].map(q => (
            <TouchableOpacity key={q.label} style={{flex:1, backgroundColor:"rgba(255,255,255,0.04)", borderRadius:14, paddingVertical:12, alignItems:"center", borderWidth:1, borderColor:"rgba(168,85,247,0.15)"}} onPress={() => Linking.openURL(q.url)}>
              <Text style={{fontSize:18, marginBottom:4}}>{q.icon}</Text>
              <Text style={{color:"#6b5a9a", fontSize:9, fontWeight:"700"}}>{q.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {history.length > 0 && (
          <View style={{width:"100%", backgroundColor:"rgba(255,255,255,0.03)", borderRadius:16, padding:14, marginBottom:20, borderWidth:1, borderColor:"rgba(255,255,255,0.06)"}}>
            <Text style={{color:"#4a3a6a", fontSize:9, letterSpacing:2, marginBottom:10, fontWeight:"700"}}>⏱ НЕЩОДАВНО ГРАЛО</Text>
            {history.map((item, i) => (
              <View key={i} style={{flexDirection:"row", alignItems:"center", marginBottom:8}}>
                {item.img && !item.img.includes("nocover") ? (
                  <Image source={{uri: IMG_BASE + item.img}} style={{width:36, height:36, borderRadius:6, marginRight:10}} />
                ) : (
                  <View style={{width:36, height:36, borderRadius:6, backgroundColor:"#1a0030", marginRight:10, alignItems:"center", justifyContent:"center"}}>
                    <Text style={{fontSize:16}}>🎵</Text>
                  </View>
                )}
                <View style={{flex:1}}>
                  <Text style={{color:"#9d6fd4", fontSize:11, lineHeight:16}} numberOfLines={1}>{item.song}</Text>
                  <Text style={{color:"#3d2f60", fontSize:9}}>{item.time}</Text>
                </View>
              </View>
            ))}
          </View>
        )}

        {favorites.length > 0 && (
          <View style={{width:"100%", backgroundColor:"rgba(168,85,247,0.06)", borderRadius:14, padding:14, marginBottom:20, borderWidth:1, borderColor:"rgba(168,85,247,0.2)"}}>
            <Text style={{color:"#7c3aed", fontSize:9, letterSpacing:2, marginBottom:8, fontWeight:"700"}}>★ ОБРАНІ ТРЕКИ</Text>
            {favorites.slice(0, 5).map((t, i) => <Text key={i} style={{color:"#9d6fd4", fontSize:11, lineHeight:20}} numberOfLines={1}>• {t}</Text>)}
          </View>
        )}

        <View style={{width:"100%", backgroundColor:"rgba(255,255,255,0.04)", borderRadius:18, padding:20, borderWidth:1, borderColor:"rgba(255,255,255,0.06)"}}>
          <Text style={{color:"#fff", fontSize:16, fontWeight:"800", marginBottom:8}}>Підтримати радіо</Text>
          <Text style={{color:"#6b5a9a", fontSize:13, lineHeight:20, marginBottom:14}}>TIS Radio існує завдяки вашій підтримці.</Text>
          <Text style={{color:"#a855f7", fontSize:17, fontWeight:"800", letterSpacing:2, textAlign:"center", marginBottom:14}}>5375 4112 0246 0460</Text>
          <TouchableOpacity style={{backgroundColor:"#6b21a8", borderRadius:14, padding:14, alignItems:"center"}} onPress={() => Linking.openURL("https://send.monobank.ua/jar/52Tw9fEaxg")}>
            <Text style={{color:"#fff", fontSize:15, fontWeight:"700"}}>Підтримати через Monobank</Text>
          </TouchableOpacity>
        </View>

      </ScrollView>
    </SafeAreaView>
  );
}
